import sys, tty, termios
from gpiozero import PWMOutputDevice, Motor

motors = [ 
    Motor(2, 3, pwm=False),   #Front left
    Motor(22, 23, pwm=False), # Front right
    Motor(14, 15, pwm=False), # Rear left
    Motor(24, 25, pwm=False)  # Rear right
    ]
pwm_out = PWMOutputDevice (18)

# get a character from the command line
def getch() :
    fd = sys.stdin.fileno()
    old_settings = termios.tcgetattr(fd)
    try:
        tty.setraw(sys.stdin.fileno())
        ch = sys.stdin.read(1)
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
    return ch

# list to convert key into motor on/off values to correspond with direction
direction = {
    # number keys
    '1' : (-1, 1, -1, 1),   # Turn left
    '2' : (-1, -1, -1, -1), # Backwards
    '3' : (1, -1, 1, -1),   # Turn right
    '4' : (-1, 1, 1, -1),   # Left
    '5' : (0, 0, 0, 0),     # Stop
    '6' : (1, -1, -1, 1),   # Right
    '7' : (0, 1, 1, 0),     # Diagonal left
    '8' : (1, 1, 1, 1),     # Forwards
    '9' : (1, 0, 0, 1)      # Diagonal right
}

current_direction = "stop"
# speed is as a percentage (ie. 100 = top speed)
speed = 50
pwm_out.value = speed/100

print ("Robot control - use number keys to control direction")
while True:
    # Get next key pressed      
    ch = getch()
    if (ch == 'q') :                    # Quit
        break
    elif (ch in direction.keys()) :     # Change direction
        for i in range (0, 4):
            if direction[ch][i] == -1:
                motors[i].backward()
            elif direction[ch][i] == 1:
                motors[i].forward()
            else:
                motors[i].stop()
        print ("Direction "+ch)