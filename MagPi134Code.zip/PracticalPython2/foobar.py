foo = 5 # foo is a variable that contains the value 5
bar = 9 # bar is a variable that contains the value 9
foobar = foo + bar # foobar is a variable that contains the sum of foo and bar
# print the value of foobar
print(f"The variable 'foobar' contains the sum of 'foo': {foo} and 'bar' {bar} which is: {foobar}")